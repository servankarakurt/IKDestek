namespace HRSupport.Domain.Common
{
    public enum Department
    {
        IK = 1,
        BT = 2,
        Muhasebe = 3,
        Pazarlama = 4,
    }
}