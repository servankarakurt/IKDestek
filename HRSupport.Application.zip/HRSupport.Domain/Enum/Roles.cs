namespace HRSupport.Domain.Common
{
    public enum Roles
    {
        Admin = 1,
        IKAdmin = 2,
        Çalışan = 3,
        Yönetici = 4,
        Stajyer = 5,
    }
}