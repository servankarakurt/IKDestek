﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HRSupport.Domain.Enum
{
    public enum LeaveStatus
    {
        Beklemede = 1,
        Reddedildi = 2,
        Onaylandı = 3
    }
}