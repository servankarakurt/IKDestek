﻿namespace HRSupport.Domain.Enum
{

    public enum LeaveType
    {
        Yıllık = 1,     
        Hastalık = 2,      
        Mazeret = 3,     
        Ücretsiz = 4     
    }
}

